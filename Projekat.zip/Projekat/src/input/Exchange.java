package input;

import java.awt.Frame;

public class Exchange extends Frame {

}
