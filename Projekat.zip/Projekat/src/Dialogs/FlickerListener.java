package Dialogs;

public interface FlickerListener {
    
	void onFlickerStateChanged(boolean isFlickering);

    
}
